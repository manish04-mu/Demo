#include "stm32f47xx.h"
#include "stm32f407xx_gpio_driver.h"
#include <stdint.h>
void delay(void)
{
	for (uint32_t i=0; i<500000; i++);
}

int main(void)
{
    GPIO_Handle_t GpioLedG;
    GPIO_Handle_t GpioLedO;
    GPIO_Handle_t GpioLedR;
    GPIO_Handle_t GpioLedB;
    GPIO_Handle_t GpioButton;

    GpioLedG.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_12;
    GpioLedO.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_13;
    GpioLedR.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_14;
    GpioLedB.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_15;
    GpioButton.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_10;


    GpioLedG.GPIO_PinConfig.GPIO_PinMode = GPIO_Mode_OUT;
    GpioLedO.GPIO_PinConfig.GPIO_PinMode = GPIO_Mode_OUT;
    GpioLedR.GPIO_PinConfig.GPIO_PinMode = GPIO_Mode_OUT;
    GpioLedB.GPIO_PinConfig.GPIO_PinMode = GPIO_Mode_OUT;
    GpioButton.GPIO_PinConfig.GPIO_PinMode = GPIO_Mode_IN;

    GpioLedG.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MED;
    GpioLedO.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MED;
    GpioLedR.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MED;
    GpioLedB.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MED;
    GpioButton.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MED;

    GpioLedG.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLedO.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLedR.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLedB.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioButton.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	GpioLedG.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;
	GpioLedO.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;
	GpioLedR.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;
	GpioLedB.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;
	GpioButton.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;


    GPIO_PeriClockControl(GPIOD, ENABLE);

    GPIO_Init(&GpioLedG);
    GPIO_Init(&GpioLedO);
    GPIO_Init(&GpioLedR);
    GPIO_Init(&GpioLedB);
    GPIO_Init(&GpioButton);

    for (uint32_t x = 0 ; x<500000 ; x++)    //put delay for 5 sec
	{
    	GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_12);
    	delay();
	}

	int x = 1;
	while (1)
	{
		if (x==1)
		{
			GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_12);
			GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_13);
			GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_14);
			GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_15);
			delay();
		}
		else if (x==2)
		{
			for (uint32_t x = 0 ; x<500000 ; x++)
			{
				GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_14);
				delay();
			}
		}
		else if (x==3)
		{
			GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_15);
			delay();
		}
		x+=1;
	}
    return 0;
}
