#ifndef INC_STM32F407XX_H_
#define INC_STM32F407XX_H_

#include <stdint.h>

/*
 * BAse address for all the memory location
 */
#define FLASH_BASEADDR  0x80000000U
#define SRAM1_BASEADDR  0x20000000U
#define SRAM2_BASEADDR  0x2001C000UL
#define ROM_BASEADDR    0x1FFF0000
#define SRAM_BASEADDR  	SRAM1_BASEADDR

/*
 * Base Address for AHBx and APBx
 */
#define AHB1PERIPH_BASEADDR  0x40020000U
#define APB1PERIPH_BASEADDR  0x40000000U
#define APB2PERIPH_BASEADDR  0x40010000U

/*
 * Base Address for peripherals on AHB1 Bus
 */
#define GPIOA_BASEADDR	(AHB1PERIPH_BASEADDR + 0x0000)
#define GPIOB_BASEADDR  (AHB1PERIPH_BASEADDR + 0x0400)
#define GPIOC_BASEADDR  (AHB1PERIPH_BASEADDR + 0x0800)
#define GPIOD_BASEADDR  (AHB1PERIPH_BASEADDR + 0x0C00)
#define GPIOE_BASEADDR  (AHB1PERIPH_BASEADDR + 0x1000)
#define GPIOF_BASEADDR  (AHB1PERIPH_BASEADDR + 0x1400)
#define GPIOG_BASEADDR  (AHB1PERIPH_BASEADDR + 0x1800)
#define GPIOH_BASEADDR  (AHB1PERIPH_BASEADDR + 0x1C00)
#define GPIOI_BASEADDR  (AHB1PERIPH_BASEADDR + 0x2000)
#define RCC_BASEADDR    (AHB1PERIPH_BASEADDR + 0x3800)

/*
 * Base Address for peripherals on APB1 Bus
 */
#define TIM2_BASEADDR   0x40000000U
#define TIM3_BASEADDR   0x40000400U
#define TIM4_BASEADDR   0x40000800U
#define TIM5_BASEADDR   0x40000C00U
#define TIM6_BASEADDR   0x40001000U
#define TIM7_BASEADDR   0x40001400U
#define TIM12_BASEADDR  0x40001800U
#define TIM13_BASEADDR  0x40001C00U
#define TIM14_BASEADDR  0x40002000U
//SPI USART CAN

/*
 * Base Address for peripherals on APB2 Bus
 */
typedef struct
{
	volatile uint32_t MODER;
	volatile uint32_t OTYPER;
	volatile uint32_t OSPEEDR;
	volatile uint32_t PUPDR;
	volatile uint32_t IDR;
	volatile uint32_t ODR;
	volatile uint32_t BSRR;
	volatile uint32_t LCKR;
	volatile uint32_t AFR[2]; // AFR[0]->AFRL  & AFR[1]->AFRH
}GPIO_RegDef_t;

typedef struct
{
	volatile uint32_t CR;
	volatile uint32_t PLLCFGR;
	volatile uint32_t CFGR;
	volatile uint32_t CIR;
	volatile uint32_t AHB1RSTR;
	volatile uint32_t AHB2RSTR;
	volatile uint32_t AHB3RSTR;
	volatile uint32_t RESERVED0;
	volatile uint32_t APB1RSTR;
	volatile uint32_t APB2RSTR;
	volatile uint32_t RESERVED1[2];
	volatile uint32_t AHB1ENR;
	volatile uint32_t AHB2ENR;
	volatile uint32_t AHB3ENR;
	volatile uint32_t RESERVED2;
	volatile uint32_t APB1ENR;
	volatile uint32_t APB2ENR;
	volatile uint32_t REVERSED3[2];
	volatile uint32_t AHB1LPENR;
	volatile uint32_t AHB2LPENR;
	volatile uint32_t AHB3LPENR;
	//start from 0x5C   Reserved
}RCC_RegDef_t;

#define GPIOA 	((GPIO_RegDef_t*) GPIOA_BASEADDR)
#define GPIOB 	((GPIO_RegDef_t*) GPIOB_BASEADDR)
#define GPIOC 	((GPIO_RegDef_t*) GPIOC_BASEADDR)
#define GPIOD 	((GPIO_RegDef_t*) GPIOD_BASEADDR)
#define GPIOE 	((GPIO_RegDef_t*) GPIOE_BASEADDR)
#define GPIOF 	((GPIO_RegDef_t*) GPIOF_BASEADDR)
#define GPIOG 	((GPIO_RegDef_t*) GPIOG_BASEADDR)
#define GPIOH 	((GPIO_RegDef_t*) GPIOH_BASEADDR)
#define GPIOI 	((GPIO_RegDef_t*) GPIOI_BASEADDR)
#define RCC		((RCC_RegDef_t*) RCC_BASEADDR)

/*
 * Enabling the Clock for GPIOs
 */

#define GPIOA_PCLK_EN()   (RCC->AHB1ENR |= (1<<0))
#define GPIOB_PCLK_EN()   (RCC->AHB1ENR |= (1<<1))
#define GPIOC_PCLK_EN()   (RCC->AHB1ENR |= (1<<2))
#define GPIOD_PCLK_EN()   (RCC->AHB1ENR |= (1<<3))
#define GPIOE_PCLK_EN()   (RCC->AHB1ENR |= (1<<4))
#define GPIOF_PCLK_EN()   (RCC->AHB1ENR |= (1<<5))
#define GPIOG_PCLK_EN()   (RCC->AHB1ENR |= (1<<6))
#define GPIOH_PCLK_EN()   (RCC->AHB1ENR |= (1<<7))
#define GPIOI_PCLK_EN()   (RCC->AHB1ENR |= (1<<8))


/*
 * Disabling the Clock for GPIOs
 */

#define GPIOA_PCLK_DI()   (RCC->AHB1ENR &= ~(1<<0))
#define GPIOB_PCLK_DI()   (RCC->AHB1ENR &= ~(1<<1))
#define GPIOC_PCLK_DI()   (RCC->AHB1ENR &= ~(1<<2))
#define GPIOD_PCLK_DI()   (RCC->AHB1ENR &= ~(1<<3))
#define GPIOE_PCLK_DI()   (RCC->AHB1ENR &= ~(1<<4))
#define GPIOF_PCLK_DI()   (RCC->AHB1ENR &= ~(1<<5))
#define GPIOG_PCLK_DI()   (RCC->AHB1ENR &= ~(1<<6))
#define GPIOH_PCLK_DI()   (RCC->AHB1ENR &= ~(1<<7))
#define GPIOI_PCLK_DI()   (RCC->AHB1ENR &= ~(1<<8))


#define GPIOA_REG_RESET()		do{	(RCC->AHB1RSTR |= (1<<0));		(RCC->AHB1RSTR &= ~(1<<0));} while(0)


/*
 * Generic API's
 */

#define ENABLE    1
#define Disable   0
#define SET		  ENABLE
#define RESET     DISABLE
#define GPIO_PIN_SET SET
#define GPIO_PIN_RESET RESET






#endif
